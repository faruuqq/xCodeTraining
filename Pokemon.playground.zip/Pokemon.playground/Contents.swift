import UIKit

//Pertarungan pokemon, pikachu dan chard Lizard secara bergantian dan akan berhenti jika salah satu mati. Dengan kondisi health Point keduanya sama 100, akan tetap serangan mereka strength berbeda chard lizard lebih strong daripada pikachu. Hanya pikachu memiliki skill unik yang bisa menghisap strength musuh.

protocol Pokemon {
    
    func attack()
    func isDead()
    //func uniquieSkill()
    
}

class Pikachu : Pokemon {
    
    var strengthPika: Int = 10
    var healthPointPika: Int = 100
    var defensePika: Int = 25
    
    func attack() {
        print("Pikachu attacks")
    }
    
    func isDead() {
        print("Pikachu is dead. Game Over!")
    }
    
    func uniquieSkill() {
        let damage = Chardlizard()
        damage.strengthChard
        strengthPika = damage.strengthChard + strengthPika
        let totalUniqueSkill = damage.strengthChard + strengthPika
        print("Pikachu Strength is now \(totalUniqueSkill)")
    }

}

class Chardlizard : Pokemon {
    
    var strengthChard: Int = 40
    var healthPoingChard: Int = 100
    var defenseChard: Int = 10
    
    func attack() {
        print("Chardlizard attacks")
    }
    
    func isDead() {
        print("Chardlizard is dead. Game Over!")
    }
}

let player1 = Pikachu()
player1.attack()
player1.isDead()
player1.uniquieSkill()

let player2 = Chardlizard()
player2.attack()
player2.isDead()

